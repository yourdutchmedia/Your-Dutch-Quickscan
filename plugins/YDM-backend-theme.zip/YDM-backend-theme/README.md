~Current Version:1.4~

# YDM-backend-theme 1.1.7!

Your Dutch Media Backend wordpress theme
```
- Plugin Name: YDM Backend Theme
- Author: Your Dutch Media
- Version: 1.1.7
- Author: https://www.yourdutchmedia.nl
```

# Changelog
```
-Fix Login link not visible
bla
-Fix Login logo link and alt text
```
# Setup
``` 
   -Download the zip file
   -install the zip on Wordpress
   -Activate the plugin
```

# Features

## Loginscreen (/wp-admin)
```
    -YDM logo
    -Login form on the right
    -New colors login form
    -New
    -YDM background image
    -responsive design
```
## New back-end theme
```
    -fresh light theme
    -Top menu background white
    -Top menu color icons grey + larger font
    -Name logged in larger font
    -background body #f7f7f7f
```
