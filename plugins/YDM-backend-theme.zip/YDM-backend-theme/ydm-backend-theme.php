<?php

/*
Plugin Name: YDM Backend Theme
Description: YDM backend theme uploaden en activeren
Author: Your Dutch Media
Version: 1.4.2
Author URI: https://www.yourdutchmedia.nl
GitHub Plugin URI: yourdutchmedia/YDM-backend-theme
GitHub Plugin URI: https://github.com/yourdutchmedia/YDM-backend-theme
*/

// ----------------------------------------------------------------------------------------
//  Add customizer support for login screen client logo
// ----------------------------------------------------------------------------------------

function login_customizer($wp_customize)
{
$wp_customize->add_setting('loginscreen_logo');
$wp_customize->add_control(new WP_Customize_Upload_Control($wp_customize, 'login_logo', array(
    'label'      => __('Loginscreen Logo', 'mytheme'),
    'section'    => 'title_tagline',
    'settings'   => 'loginscreen_logo',
)));
}

add_action('customize_register', 'login_customizer');

// ----------------------------------------------------------------------------------------
//  Remove wp_auth_check
// ----------------------------------------------------------------------------------------

remove_action( 'admin_enqueue_scripts', 'wp_auth_check_load' );
remove_filter( 'heartbeat_send',        'wp_auth_check' );
remove_filter( 'heartbeat_nopriv_send', 'wp_auth_check' );

// ----------------------------------------------------------------------------------------
//  Include login page
// ----------------------------------------------------------------------------------------

include( plugin_dir_path( __FILE__ ) . '/admin/login.php');


require( plugin_dir_path( __FILE__ ) .  'plugin-update-checker/plugin-update-checker.php');
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://github.com/yourdutchmedia/YDM-backend-theme/',
    __FILE__,
    'YDM-backend-theme'
);

//Optional: If you're using a private repository, specify the access token like this:
$myUpdateChecker->setAuthentication('2c453f8b28e15e94ab866898e9974318610ecc03');

//Optional: Set the branch that contains the stable release.
$myUpdateChecker->setBranch('master');
