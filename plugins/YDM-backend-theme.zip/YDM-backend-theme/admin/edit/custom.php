<?php

function branding2_customizer($wp_customize)
{
    $wp_customize->add_setting('loginscreen_logo');
    $wp_customize->add_control(new WP_Customize_Upload_Control($wp_customize, 'login_logo', array(
        'label'      => __('Loginscreen Logo', 'mytheme'),
        'section'    => 'title_tagline',
        'settings'   => 'loginscreen_logo',
    )));
}
add_action('customize_register', 'branding2_customizer');