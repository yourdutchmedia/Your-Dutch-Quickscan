var today = new Date()
var curHr = today.getHours()

if (curHr < 12) {
    console.log('Goedemorgen')
    document.getElementById("h1_element").innerHTML = "Goedemorgen<span>.</span>";

} else if (curHr < 18) {
    console.log('Goedemiddag')
    document.getElementById("h1_element").innerHTML = "Goedemiddag<span>.</span>";
} else {
    console.log('Goedeavond')
    document.getElementById("h1_element").innerHTML = "Goedeavond<span>.</span>";

}