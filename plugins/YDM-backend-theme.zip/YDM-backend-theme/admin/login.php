<?php

// ----------------------------------------------------------------------------------------
//  Enqueue admin styles
// ----------------------------------------------------------------------------------------

function admin_style() {
    wp_enqueue_style('admin-styles', plugin_dir_url( __FILE__ ) . 'assets/css/dashboard.css' );
}
add_action('admin_enqueue_scripts', 'admin_style');

// ----------------------------------------------------------------------------------------
//  Enqueue login styles
// ----------------------------------------------------------------------------------------

function login_head()
{
    wp_enqueue_script( 'login', plugin_dir_url( __FILE__ ) . '/assets/js/login.js' );
    echo '<link rel="stylesheet" type="text/css" href="' .plugins_url('assets/css/bootstrap.css  ', __FILE__). '"/>';
    echo '<link rel="stylesheet" type="text/css" href="' .plugins_url('assets/css/login.css  ', __FILE__). '"/>';

}

add_action('login_head', 'login_head');

// ----------------------------------------------------------------------------------------
//  Add customizer support for login screen client logo
// ----------------------------------------------------------------------------------------

require 'edit/custom.php';

// ----------------------------------------------------------------------------------------
//  Custom login
// ----------------------------------------------------------------------------------------

function login_before_form()
{

    echo '
<div id="ydm-login">
    <div class="container-fluid" style="padding: 0;">
        <div class="row no-gutters">
            <div class="col-xl-8 col-lg-7 col-md-6">
                <div class="customer-branding">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-10">
                            <img class="client-logo" src="'. get_theme_mod('loginscreen_logo') . '" alt="Client logo" style="max-width: 100%; width: 500px; height: auto;">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5 col-md-6">
                <div class="ydm-branding">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-10">
                            <img src="https://yourdutch.media/storage/app/media/LogoYDM.svg" alt="Your Dutch Media Logo">
                            <div id="login-form-wrapper-center">';
                                if ($_GET['action'] == 'lostpassword') {
                                    echo '<div class="intro-text"><h1>Geen paniek<span>.</span></h1>Kun je niet meer inloggen? We helpen je graag weer op weg. Vul je gebruikersnaam in en we sturen je instructies om je wachtwoord opnieuw in te stellen zodat je weer verder kunt.</div>';
                                } elseif ($_GET['action'] == 'rp') {
                                    echo '<div class="intro-text"><h1>Wachtwoord<span>.</span></h1>Vul hieronder je nieuwe wachtwoord in.</div>';
                                } elseif ($_GET['action'] == 'register') {
                                    echo '<div class="intro-text"><h1>Welkom<span>.</span></h1>Ben je nieuw hier? Vul een gebruikersnaam en je e-mailadres in om te registreren.</div>';
                                } elseif ($_GET['checkemail'] == 'confirm') {
                                    echo '<div class="intro-text"><h1>Gelukt<span>.</span></h1>Controleer je inbox en klik op de link om een nieuw wachtwoord in te stellen.</div>';
                                } else {
                                    echo '<div class="intro-text"><h1 id="h1_element">Welkom</h1>Gebruik jouw persoonlijke gebruikersnaam en wachtwoord om in te loggen in het WordPress CMS voor toegang tot het beheer van jouw website.</div>';
                                }

                                }

                                add_filter('login_header', 'login_before_form', 10, 4);
function login_after_form() {
    echo '</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    ';
}
add_filter( 'login_footer', 'login_after_form', 10, 4 );
?>